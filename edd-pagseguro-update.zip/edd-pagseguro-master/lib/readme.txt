PagSeguro PHP Library - version 2.1.0
 
Please refer to the online documentation:
 
 - How to use PagSeguro as a payment solution for your website using the PagSeguro PHP Library:
    https://pagseguro.uol.com.br/v2/guia-de-integracao/tutorial-da-biblioteca-pagseguro-em-php.html
 
 - Class library documentation:
    https://pagseguro.uol.com.br/v2/guia-de-integracao/documentacao-da-biblioteca-pagseguro-em-php.html
 
 - General documentation about our APIs:
    https://pagseguro.uol.com.br/v2/guia-de-integracao/visao-geral.html
     
 - Community:
    https://pagseguro.uol.com.br/desenvolvedor/comunidade.jhtml