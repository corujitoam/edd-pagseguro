# edd-pagseguro
PagSeguro payment gateway for Easy Digital Downloads
